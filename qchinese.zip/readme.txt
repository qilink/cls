This software requires Java JRE 1.5 and above to be installed in your operating system. 

Just unzip the files to a suitable location, no installation required.

On Windows platform: To run type run.bat

On other platform: java -jar ./dist/cc.jar

